<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ViewController extends CI_Controller {
	/* FRONTEND CONTROLLER */
	public function index(){
		
		$this->load->view('frontend/pages/signin');
	}

	public function signin(){
		$data = [
			'title' => 'Sign-in User',
			'pages' => 'signin'
		];

		$this->load->view('frontend/pages/signin', $data);
	}

	

	public function Logout(){
		$this->session->sess_destroy();
		redirect(base_url(''));
	}

	public function dashboard(){



           /*$this->db = $this->load->database('default',TRUE);

           if(!empty($this->db))
                   echo "Connected!"."\n";
           else
                   echo "Closed"."\n";*/
                   $query = $this->db->query('SELECT * FROM CAPSPLAN_DATA');

		// foreach ($query->result() as $row)
		// {
		//         echo $row->OS;
		//         //echo $row->name;
		//         //echo $row->email;
		// }

		// echo 'Total Results: ' . $query->num_rows();
		// die();   
		//$dataUser = $this->db->get('CAPSPLAN_DATA');
		$dataUser = $query->result_array();
		//print_r($dataUser); die();
		$data = [
			'title' => 'Manage Capsplan Data',
			'pages' => 'user_dashboard',
			'user' => $dataUser
		];
		$this->load->view('frontend/template/header');
		$this->load->view('frontend/pages/dashboard', $data);
		$this->load->view('frontend/template/footer');
	}

}

/* End of file ViewController.php */
/* Location: ./application/controllers/ViewController.php */