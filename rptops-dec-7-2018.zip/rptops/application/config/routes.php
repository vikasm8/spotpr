<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/*
	| Frontend Routes
*/

// GET METHOD

$route['default_controller'] = 'ViewController';
$route['dashboard'] = 'ViewController/dashboard';
$route['sign-in'] = 'ViewController/signin';

$route['admin/logout'] = 'ViewController/adminLogout';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
