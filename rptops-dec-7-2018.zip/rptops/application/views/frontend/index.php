

	<?php  
		
		$this->load->view('frontend/pages/'.$pages);
		
	?>
	