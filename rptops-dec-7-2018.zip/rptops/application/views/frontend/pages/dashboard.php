



<style type="text/css">
.card-header.card-header-icon {
    background: #1a4bb1;
}
tr {
    font-size: 11px;
    font-color: #1a4bb1;
}
    </style>


<div class="content">
    <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              
              <div class="card-content">
                <div class="card-header card-header-icon" data-background-color="purple">
                        <i class="material-icons">AA</i>
                </div>
                
                <h4 class="card-title">Master Server Inventory</h4>
                <div class="clearfix"></div>
                
                <div class="material-datatables table-responsive">
                    <table class="table" id="example2">
                          <thead class="text-primary">
                              <th>S.NO</th>
                              <th>SERVER</th>
                              <th>OS</th>
                              <th>BLADE</th>
                              <th>APPLICATION</th>
                              <th>COMPONENT</th>
                              <th>ENVIRONMENT</th>
                              <th>DATA_CENTER</th>
                              <th>COST_CENTER</th>
                              <th>MRC_COST_CENTER</th>
                              <th>APP_READY</th>
                              <th>FINAL_TIER_LEVEL</th>
                              <th>HP_TIER_LEVEL</th>
                              <th>PRODUCT</th>
                              

                              <th>Action</th>
                          </thead>
                          <tbody>
                              <?php 
                              if(!empty($user))
                              {  
                                  $i=0;
                                  //echo "<pre>";print_r($reseller); die();
                                  foreach($user as $data_array)
                                  {
                                      $i++;
                                      ?>
                                      <tr>
                                          <!-- <td><?php //echo $data_array['customer_code']?></td> -->
                                          <td><?php echo $i?></td>
                                          <td><?php echo (isset($data_array['SERVER']) ? $data_array['SERVER'] : 'none');?></td>
                                    
                                          <td><?php echo (!empty($data_array['OS'])?$data_array['OS']:''); ?></td>
                                          <td><?php echo (!empty($data_array['BLADE'])?$data_array['BLADE']:'')  ?></td>
                                          <td><?php echo (!empty($data_array['APPLICATION'])?$data_array['APPLICATION']:''); ?></td>
                                          <td><?php echo (!empty($data_array['COMPONENT'])?$data_array['COMPONENT']:''); ?></td>
                                          <td><?php echo (!empty($data_array['ENVIRONMENT'])?$data_array['ENVIRONMENT']:''); ?></td>
                                           <td><?php echo (!empty($data_array['DATA_CENTER'])?$data_array['DATA_CENTER']:''); ?></td>
                                          <td><?php echo (!empty($data_array['COST_CENTER'])?$data_array['COST_CENTER']:''); ?></td>
                                          
                                          <td><?php echo (!empty($data_array['MRC_COST_CENTER'])?$data_array['MRC_COST_CENTER']:''); ?></td>
                                          
                                          <td><?php echo (!empty($data_array['APP_READY'])?$data_array['APP_READY']:''); ?></td>
                                          
                                          <td><?php echo (!empty($data_array['FINAL_TIER_LEVEL'])?$data_array['FINAL_TIER_LEVEL']:''); ?></td>
                                          
                                          <td><?php echo (!empty($data_array['HP_TIER_LEVEL'])?$data_array['HP_TIER_LEVEL']:''); ?></td>
                                          
                                          <td><?php echo (!empty($data_array['PRODUCT'])?$data_array['PRODUCT']:''); ?></td>
                                          <td>
                                            
                                                  <a href="javascript:void(0)" href-status="1" href-id="<?php //echo $data_array['id']?>" class="status"><i class="fa fa-check-square" aria-hidden="true"></i>View</a>
                                                  
                                              
                                              <a href="javascript:void(0)" href-data="<?php //echo  $data_array['id']; ?>" class="delete">
                                                  <i class="fa fa-trash-o" aria-hidden="true">Delete</i>
                                              </a>
                                             
                                               
                                          </td>
                                      </tr>
                                      <?php 
                                  }
                              }
                              ?>
                              <!-- Modal -->
                              <!--<div class="modal fade" id="myModal" role="dialog">
                              <div class="modal-dialog"> -->
                          </tbody>
                    </table>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>   
<script type="text/javascript">
	$(function () {
	    $('#example2').DataTable({
	      "paging": true,
	      // "lengthChange": false,
	      "searching": true,
	      "ordering": true,
	      // "info": true,
	      // "autoWidth": false
	    });
	});
</script> 

<style type="text/css">
    table.dataTable > thead > tr > th,
    table.dataTable > tbody > tr > th,
    table.dataTable > tfoot > tr > th,
    table.dataTable > thead > tr > td,
    table.dataTable > tbody > tr > td,
    table.dataTable > tfoot > tr > td {
      padding: 5px !important;
      outline: 0;
      border-top: 1px solid #ddd !important;
      border-left: 1px solid #ddd !important;
      border-bottom: 1px solid #ddd !important;
      border-right: 1px solid #ddd !important;
    }
</style> 